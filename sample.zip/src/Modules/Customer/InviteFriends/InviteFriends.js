
import React, { Component } from 'react';
import { Text , View } from 'react-native'

class InviteFriends extends Component {
    state = {  }
    render() {
        return (
          <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
                <Text>This is Invite Friends Screen</Text>
            </View>
        );
    }
}

export default InviteFriends;