import React, { Component } from 'react';
import { Text , View } from 'react-native'

class RateApplication extends Component {
    state = {  }
    render() {
        return (
            <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
                <Text>This is Rate Application Screen</Text>
            </View>
        );
    }
}

export default RateApplication;