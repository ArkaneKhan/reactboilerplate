import HttpServiceManager from '../../../HttpServiceManager/HttpServiceManager';
import constant from '../../../HttpServiceManager/constant';
import ActionTypes from '../../../Store/Types';
import { NavigationActions } from 'react-navigation'

